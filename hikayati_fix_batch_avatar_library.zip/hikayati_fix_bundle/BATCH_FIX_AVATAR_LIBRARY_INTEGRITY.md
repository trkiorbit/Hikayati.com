# Batch واحدة: Fix Avatar Real Flow + Library Integrity

## ما تم تجهيزه
هذه الحزمة تبني نفس المنطق الذي طلبته بدون تحليل صورة وبدون إدخال يدوي لملامح الطفل:

1. رفع صورة الطفل الأصلية.
2. حفظ الصورة في Supabase Storage.
3. توليد 4 أفاتارات حقيقية عبر Image API اعتمادًا على نفس الصورة المرجعية.
4. حفظ:
   - original_image
   - avatar_options
   - selected_avatar
   - current_clothes
5. إصلاح تحميل المكتبة بحيث يقرأ `scenes_json` أو `scenes` ولا يعرض "لا توجد مشاهد" إذا كانت البيانات موجودة.
6. إصلاح Pollinations 401 عبر retry بدون Authorization إذا كان الرد 401.

## الملفات الجاهزة
- `lib/models/avatar_bundle.dart`
- `lib/utils/story_image_prompt_builder.dart`
- `lib/services/pollinations_image_service_fixed.dart`
- `lib/services/avatar_real_flow_service.dart`
- `lib/services/private_library_service.dart`
- `lib/services/supabase_story_save_patch.dart`
- `sql/avatar_and_library_fix.sql`

## الدمج المتوقع داخل المشروع

### 1) AvatarScreen / AvatarLab
- احذف أي حقول إدخال يدوي مثل age/gender/skinTone/hair/eyeColor/name.
- عند اختيار الصورة نفّذ:
```dart
final bundle = await AvatarRealFlowService().createAvatarOptions(childImage: File(path));
setState(() => _bundle = bundle);
```
- اعرض الأربع نتائج في Grid.
- عند اختيار صورة واحدة:
```dart
await AvatarRealFlowService().selectAvatar(avatarUrl);
```

### 2) Story generation image prompt
بدل تمرير prompt الخام مباشرة استخدم:
```dart
final prompt = StoryImagePromptBuilder.build(
  sceneDescription: sceneDescription,
  selectedAvatarUrl: selectedAvatar,
  currentClothes: currentClothes,
  style: selectedStyle,
);
```

### 3) المكتبة الخاصة
بدل أي `Coming Soon` أو جلب ناقص استخدم:
```dart
final stories = await PrivateLibraryService().getMyStories();
```
وعند فتح قصة:
```dart
final scenes = await PrivateLibraryService().loadStoryScenes(storyId);
```

### 4) زر الرجوع
في شاشة المكتبة:
```dart
appBar: AppBar(
  leading: IconButton(
    icon: const Icon(Icons.arrow_back),
    onPressed: () => Navigator.of(context).pop(),
  ),
)
```

### 5) إصلاح Pollinations 401
بدل الخدمة الحالية بخدمة `PollinationsImageServiceFixed` أو انسخ منطق الـ retry داخل خدمتك الحالية.

## كيف تم توليد 4 الأفاتارات
- الصورة الأصلية تُرفع أولًا إلى bucket `avatars`.
- يتم تكوين 4 prompts مختلفة قليلًا لكن كلها تشير إلى نفس الصورة المرجعية.
- كل طلب يُرسل إلى Image API مع seed مختلف ثابت.
- النتيجة: 4 خيارات قريبة من الطفل بدون أي وصف يدوي وبدون Vision.

## كيف يتم حفظ المختار
- الخيارات الأربعة تُحفظ في `profiles.avatar_options`.
- الصورة الأصلية في `profiles.original_image`.
- الأفاتار المختار في `profiles.selected_avatar`.
- الملابس الحالية في `profiles.current_clothes`.

## هل الصور أصبحت ثابتة؟
أصبحت أكثر ثباتًا من التدفق القديم لأن التوليد صار يعتمد على:
- selected_avatar واحد ثابت
- current_clothes
- style ثابت
- prompt structure ثابت

لكن الثبات الكامل 100% يعتمد أيضًا على دمج `StoryImagePromptBuilder` في مسار توليد كل مشهد، وليس فقط في شاشة الأفاتار.

## اختبار التنفيذ

### إنشاء أفاتار
1. افتح شاشة الأفاتار.
2. ارفع صورة طفل واحدة.
3. تأكد أن النظام يعرض 4 نتائج حقيقية.
4. تأكد أن جدول `profiles` امتلأ بالحقول الأربعة المطلوبة.

### اختيار واحد
1. اضغط على أحد الخيارات.
2. تأكد أن `selected_avatar` تغير في Supabase.
3. أغلق الشاشة وافتحها وتأكد أن المختار ما زال ظاهرًا.

### فتح المكتبة
1. افتح مكتبتي.
2. تأكد أن القصص المحفوظة تظهر.
3. افتح قصة محفوظة.
4. تأكد أن `loadStoryScenes` يعيد scenes فعلية ولا تظهر رسالة "لا توجد مشاهد" إذا كانت `scenes_json` أو `scenes` موجودة.

## ملاحظة تنفيذية صريحة
لم أعدّل المستودع الأصلي مباشرة لأن كود المشروع نفسه غير موجود داخل الجلسة الحالية. جهزت لك حزمة الدمج الفعلية، والدمج سيكون داخل الملفات الحالية عندك بنفس المنطق أعلاه، بدون إعادة بناء للفكرة.
