class AvatarBundle {
  final String originalImage;
  final List<String> avatarOptions;
  final String? selectedAvatar;
  final String currentClothes;

  const AvatarBundle({
    required this.originalImage,
    required this.avatarOptions,
    required this.selectedAvatar,
    required this.currentClothes,
  });

  Map<String, dynamic> toJson() => {
        'original_image': originalImage,
        'avatar_options': avatarOptions,
        'selected_avatar': selectedAvatar,
        'current_clothes': currentClothes,
      };

  factory AvatarBundle.fromJson(Map<String, dynamic> json) {
    final rawOptions = (json['avatar_options'] as List<dynamic>? ?? const []);
    return AvatarBundle(
      originalImage: json['original_image']?.toString() ?? '',
      avatarOptions: rawOptions.map((e) => e.toString()).toList(),
      selectedAvatar: json['selected_avatar']?.toString(),
      currentClothes: json['current_clothes']?.toString() ?? 'default outfit',
    );
  }

  AvatarBundle copyWith({
    String? originalImage,
    List<String>? avatarOptions,
    String? selectedAvatar,
    String? currentClothes,
  }) {
    return AvatarBundle(
      originalImage: originalImage ?? this.originalImage,
      avatarOptions: avatarOptions ?? this.avatarOptions,
      selectedAvatar: selectedAvatar ?? this.selectedAvatar,
      currentClothes: currentClothes ?? this.currentClothes,
    );
  }
}
