class StoryImagePromptBuilder {
  static String build({
    required String sceneDescription,
    String? selectedAvatarUrl,
    String? currentClothes,
    required String style,
  }) {
    final base = sceneDescription.trim();
    if (selectedAvatarUrl == null || selectedAvatarUrl.isEmpty) {
      return '$base\n\nStyle: $style';
    }

    final clothes = (currentClothes == null || currentClothes.trim().isEmpty)
        ? 'same clothes as saved avatar'
        : currentClothes.trim();

    return '''$base

Main character:
Use the exact same child identity from this selected avatar reference: $selectedAvatarUrl

Wearing:
$clothes

Style:
$style

Same character across all scenes.''';
  }
}
