import 'package:supabase_flutter/supabase_flutter.dart';

class SupabaseStorySavePatch {
  final SupabaseClient _client;

  SupabaseStorySavePatch({SupabaseClient? client})
      : _client = client ?? Supabase.instance.client;

  Future<void> saveStory({
    required String title,
    required List<Map<String, dynamic>> scenes,
    String? coverImageUrl,
    int? cost,
    String sourceType = 'generated',
    String audioMode = 'normal',
    String language = 'ar',
  }) async {
    final userId = _client.auth.currentUser?.id;
    if (userId == null) throw Exception('User not authenticated');

    final row = <String, dynamic>{
      'user_id': userId,
      'title': title,
      'language': language,
      'scenes_json': scenes,
      'cover_image_url': coverImageUrl,
      'audio_mode': audioMode,
      'source_type': sourceType,
      if (cost != null) 'cost': cost,
    };

    try {
      await _client.from('stories').insert(row);
    } catch (e) {
      final err = e.toString().toLowerCase();
      if (err.contains('cover_image_url')) {
        row.remove('cover_image_url');
        row['cover_image'] = coverImageUrl;
      }
      if (err.contains('cost')) {
        row.remove('cost');
      }
      await _client.from('stories').insert(row);
    }
  }
}
