import 'dart:convert';
import 'package:http/http.dart' as http;

class PollinationsImageServiceFixed {
  final String? apiKey;
  final http.Client _client;

  PollinationsImageServiceFixed({
    required this.apiKey,
    http.Client? client,
  }) : _client = client ?? http.Client();

  Future<String> generateImage({
    required String prompt,
    int width = 1024,
    int height = 1024,
    int seed = 0,
    String model = 'flux',
  }) async {
    final encodedPrompt = Uri.encodeComponent(prompt);
    final uri = Uri.parse(
      'https://image.pollinations.ai/prompt/$encodedPrompt?width=$width&height=$height&seed=$seed&model=$model',
    );

    final authHeaders = <String, String>{
      'Accept': 'image/*',
      if (apiKey != null && apiKey!.trim().isNotEmpty)
        'Authorization': 'Bearer ${apiKey!.trim()}',
    };

    final first = await _client.get(uri, headers: authHeaders);
    if (first.statusCode == 200) {
      return uri.toString();
    }

    if (first.statusCode == 401) {
      final retry = await _client.get(uri, headers: const {'Accept': 'image/*'});
      if (retry.statusCode == 200) {
        return uri.toString();
      }
    }

    throw Exception(
      'Pollinations image generation failed: ${first.statusCode} ${utf8.decode(first.bodyBytes)}',
    );
  }
}
