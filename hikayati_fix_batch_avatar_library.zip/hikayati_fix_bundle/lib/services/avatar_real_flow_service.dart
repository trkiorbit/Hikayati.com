import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:path/path.dart' as p;
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/avatar_bundle.dart';
import 'pollinations_image_service_fixed.dart';

class AvatarRealFlowService {
  final SupabaseClient _supabase;
  final PollinationsImageServiceFixed _images;

  AvatarRealFlowService({
    SupabaseClient? supabase,
    PollinationsImageServiceFixed? images,
  })  : _supabase = supabase ?? Supabase.instance.client,
        _images = images ?? PollinationsImageServiceFixed(apiKey: null);

  Future<AvatarBundle> createAvatarOptions({required File childImage}) async {
    final userId = _supabase.auth.currentUser?.id;
    if (userId == null) throw Exception('User not authenticated');

    final originalImageUrl = await _uploadOriginalImage(userId, childImage);

    final prompts = <String>[
      'Create a child story avatar that preserves the same identity from the reference photo. Warm storybook portrait, clean background, expressive eyes, cinematic illustration. Reference photo: $originalImageUrl',
      'Create a child hero avatar from the reference photo with the same identity preserved. Friendly illustrated portrait, magical lighting, premium children story app style. Reference photo: $originalImageUrl',
      'Create a polished family-safe avatar from the reference child photo, same identity preserved, charming story illustration, soft cinematic light. Reference photo: $originalImageUrl',
      'Create a premium animated story avatar from the reference child photo, same child identity preserved, balanced features, clean portrait framing. Reference photo: $originalImageUrl',
    ];

    final List<String> optionUrls = [];
    for (var i = 0; i < prompts.length; i++) {
      final imageUrl = await _images.generateImage(
        prompt: prompts[i],
        seed: 1100 + i,
      );
      optionUrls.add(imageUrl);
    }

    final bundle = AvatarBundle(
      originalImage: originalImageUrl,
      avatarOptions: optionUrls,
      selectedAvatar: null,
      currentClothes: 'default outfit',
    );

    await saveAvatarBundle(bundle);
    return bundle;
  }

  Future<void> saveAvatarBundle(AvatarBundle bundle) async {
    final userId = _supabase.auth.currentUser?.id;
    if (userId == null) throw Exception('User not authenticated');

    await _supabase.from('profiles').update(bundle.toJson()).eq('id', userId);
  }

  Future<void> selectAvatar(String avatarUrl) async {
    final userId = _supabase.auth.currentUser?.id;
    if (userId == null) throw Exception('User not authenticated');

    await _supabase.from('profiles').update({
      'selected_avatar': avatarUrl,
    }).eq('id', userId);
  }

  Future<AvatarBundle?> loadCurrentAvatarBundle() async {
    final userId = _supabase.auth.currentUser?.id;
    if (userId == null) return null;

    final row = await _supabase
        .from('profiles')
        .select('original_image, avatar_options, selected_avatar, current_clothes')
        .eq('id', userId)
        .maybeSingle();

    if (row == null) return null;
    return AvatarBundle.fromJson(row);
  }

  Future<String> _uploadOriginalImage(String userId, File file) async {
    final ext = p.extension(file.path).replaceFirst('.', '').toLowerCase();
    final path = 'avatars/$userId/original_${DateTime.now().millisecondsSinceEpoch}.$ext';
    await _supabase.storage.from('avatars').upload(path, file,
        fileOptions: const FileOptions(upsert: true));
    return _supabase.storage.from('avatars').getPublicUrl(path);
  }
}
