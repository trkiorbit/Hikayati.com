import 'dart:convert';
import 'package:supabase_flutter/supabase_flutter.dart';

class PrivateLibraryService {
  final SupabaseClient _supabase;

  PrivateLibraryService({SupabaseClient? supabase})
      : _supabase = supabase ?? Supabase.instance.client;

  Future<List<Map<String, dynamic>>> getMyStories() async {
    final userId = _supabase.auth.currentUser?.id;
    if (userId == null) return [];

    final rows = await _supabase
        .from('stories')
        .select('id, title, created_at, cover_image_url, cover_image, scenes_json, scenes')
        .eq('user_id', userId)
        .order('created_at', ascending: false);

    return List<Map<String, dynamic>>.from(rows).map(_normalizeStory).toList();
  }

  Future<List<Map<String, dynamic>>> loadStoryScenes(String storyId) async {
    final row = await _supabase
        .from('stories')
        .select('id, scenes_json, scenes')
        .eq('id', storyId)
        .single();

    final normalized = _normalizeStory(Map<String, dynamic>.from(row));
    final scenes = normalized['scenes'] as List<dynamic>? ?? const [];
    return scenes.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Map<String, dynamic> _normalizeStory(Map<String, dynamic> row) {
    final cover = row['cover_image_url'] ?? row['cover_image'];
    final rawScenes = row['scenes_json'] ?? row['scenes'];

    List<dynamic> scenes = [];
    if (rawScenes is List) {
      scenes = rawScenes;
    } else if (rawScenes is String && rawScenes.trim().isNotEmpty) {
      final decoded = jsonDecode(rawScenes);
      if (decoded is List) scenes = decoded;
    }

    return {
      ...row,
      'cover_image_url': cover,
      'scenes': scenes,
      'has_scenes': scenes.isNotEmpty,
    };
  }
}
