-- Batch: Fix Avatar Real Flow + Library Integrity
-- Safe additive migration.

alter table if exists profiles
  add column if not exists original_image text,
  add column if not exists avatar_options jsonb default '[]'::jsonb,
  add column if not exists selected_avatar text,
  add column if not exists current_clothes text default 'default outfit';

alter table if exists stories
  add column if not exists scenes_json jsonb default '[]'::jsonb,
  add column if not exists cover_image_url text,
  add column if not exists cost integer;

create index if not exists idx_stories_user_created_at
  on stories(user_id, created_at desc);
